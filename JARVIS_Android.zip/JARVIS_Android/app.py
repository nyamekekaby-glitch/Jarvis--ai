import os,sqlite3
from pathlib import Path
from dotenv import load_dotenv
from flask import Flask,request,jsonify,render_template
from openai import OpenAI
BASE=Path(__file__).resolve().parent
load_dotenv(BASE/".env")
app=Flask(__name__)
DB=BASE/"jarvis_mobile.db"
def init():
 with sqlite3.connect(DB) as c:c.execute("CREATE TABLE IF NOT EXISTS chat(id INTEGER PRIMARY KEY,role TEXT,content TEXT)")
init()
@app.get("/")
def home():return render_template("index.html")
@app.get("/history")
def history():
 with sqlite3.connect(DB) as c: rows=c.execute("SELECT role,content FROM chat ORDER BY id DESC LIMIT 30").fetchall()
 return jsonify([{"role":r,"content":m} for r,m in reversed(rows)])
@app.post("/clear")
def clear():
 with sqlite3.connect(DB) as c:c.execute("DELETE FROM chat")
 return jsonify(ok=True)
@app.post("/chat")
def chat():
 msg=(request.json.get("message") or "").strip()
 if not msg:return jsonify(error="Type a message first."),400
 key=os.getenv("OPENAI_API_KEY","")
 if not key or key.startswith("replace_"):return jsonify(error="Add your API key to .env in Termux, then restart."),400
 with sqlite3.connect(DB) as c:
  c.execute("INSERT INTO chat(role,content) VALUES('user',?)",(msg,))
  rows=c.execute("SELECT role,content FROM chat ORDER BY id DESC LIMIT 16").fetchall()
 hist=[{"role":r,"content":m} for r,m in reversed(rows)]
 try:
  result=OpenAI(api_key=key).responses.create(model=os.getenv("OPENAI_MODEL","gpt-4.1-mini"),instructions="You are JARVIS, a helpful concise AI assistant running on Android. Be honest: you cannot control the phone, open apps, or perform actions. Never claim actions were done.",input=hist)
  answer=result.output_text
 except Exception as e:return jsonify(error=str(e)),500
 with sqlite3.connect(DB) as c:c.execute("INSERT INTO chat(role,content) VALUES('assistant',?)",(answer,))
 return jsonify(answer=answer)
if __name__=="__main__":app.run(host="127.0.0.1",port=5000)
